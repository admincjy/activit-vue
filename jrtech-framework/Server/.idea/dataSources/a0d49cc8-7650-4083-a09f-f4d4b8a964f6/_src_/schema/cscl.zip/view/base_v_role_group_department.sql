CREATE VIEW base_v_role_group_department AS
  SELECT
    `a`.`id`             AS `id`,
    `a`.`organizationId` AS `organizationId`,
    `a`.`name`           AS `name`,
    `a`.`remark`         AS `remark`,
    `a`.`type`           AS `type`,
    `a`.`roleCategoryId` AS `roleCategoryId`,
    `a`.`gmtCreatedBy`   AS `gmtCreatedBy`,
    `a`.`gmtCreatedOn`   AS `gmtCreatedOn`,
    `a`.`gmtUpdatedBy`   AS `gmtUpdatedBy`,
    `a`.`gmtUpdatedOn`   AS `gmtUpdatedOn`,
    `a`.`gmtVersion`     AS `gmtVersion`,
    `b`.`id`             AS `groupId`,
    `b`.`name`           AS `groupName`,
    `b`.`departmentId`   AS `departmentId`,
    `b`.`departmentName` AS `departmentName`
  FROM (`hq`.`base_role` `a` LEFT JOIN `hq`.`base_v_group_department` `b` ON ((`a`.`organizationId` = `b`.`id`)));
