CREATE VIEW act_id_membership AS
  (SELECT
     `sr`.`userId` AS `USER_ID_`,
     `sr`.`roleId` AS `GROUP_ID_`
   FROM `cscl`.`base_user_role` `sr`);
