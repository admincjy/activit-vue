CREATE FUNCTION base_getOrganizationOfDepartmentId(p_orgId VARCHAR(32))
  RETURNS VARCHAR(100)
  BEGIN

	DECLARE v_thisId VARCHAR(100);

	DECLARE v_parentId VARCHAR(100); 

	DECLARE v_orgCategoryId NVARCHAR(50); 

	

	SELECT Id,ParentId,organizationCategoryId FROM base_organization WHERE Id = p_orgId INTO   v_thisId,v_parentId,v_orgCategoryId;

	

	IF  v_orgCategoryId = 'base_organizationcategory_company' || v_orgCategoryId = 'base_organizationcategory_department'  THEN

		RETURN v_thisId;

	END IF;

	

	WHILE v_orgCategoryId != 'base_organizationcategory_department' && EXISTS(SELECT 1 FROM Base_Organization WHERE Id = v_parentId ) DO

		SELECT Id,ParentId,OrganizationCategoryId FROM Base_Organization WHERE Id = v_parentId INTO   v_thisId,v_parentId,v_orgCategoryId;

		IF v_orgCategoryId != 'base_organizationcategory_department' THEN

		   RETURN v_thisId;

		END IF;

	END WHILE;

	

    RETURN v_thisId;

    

END;
