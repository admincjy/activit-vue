CREATE FUNCTION base_getOrganizationNamePath(p_orgId VARCHAR(100))
  RETURNS VARCHAR(2000)
  BEGIN

	DECLARE v_path VARCHAR(2000);

	DECLARE v_thisId VARCHAR(100);

	DECLARE v_parentId VARCHAR(100);

	DECLARE v_tname VARCHAR(100);

	SELECT Id,parentId,NAME FROM Base_Organization WHERE Id = p_orgId INTO v_thisId ,v_parentId,v_path;

	

	WHILE v_parentId IS NOT NULL && EXISTS(SELECT 1 FROM Base_Organization WHERE Id = v_parentId) DO

		SELECT Id,parentId,NAME FROM Base_Organization WHERE Id = v_parentId  INTO v_thisId ,v_parentId,v_tname;

		SET v_path = CONCAT(v_path , '->' , v_tname);

	END WHILE;

	

    RETURN v_path;

	 

    

END;
