CREATE VIEW wf_v_processinsthistory AS
  SELECT
    `a`.`id`                                   AS `id`,
    `a`.`id`                                   AS `processInstId`,
    `a`.`origiator`                            AS `actUserId`,
    `BASE_GETUSERDISPLAYNAME`(`a`.`origiator`) AS `actUserName`,
    '客户咨询'                                     AS `actId`,
    '客户咨询'                                     AS `actName`,
    'Submit'                                   AS `doAction`,
    '提交'                                       AS `result`,
    ''                                         AS `remark`,
    `a`.`startDate`                            AS `startDate`,
    `a`.`startDate`                            AS `endDate`,
    '已提交'                                      AS `status`
  FROM `cscl`.`wf_processinst` `a`
  UNION ALL SELECT
              `a`.`id`                                              AS `id`,
              `a`.`processInstId`                                   AS `ProcessInstId`,
              (CASE WHEN isnull(`a`.`actUserId`)
                THEN `a`.`actPlanUserId`
               ELSE `a`.`actUserId` END)                            AS `actUserId`,
              `BASE_GETUSERDISPLAYNAME`((CASE WHEN isnull(`a`.`actUserId`)
                THEN `a`.`actPlanUserId`
                                         ELSE `a`.`actUserId` END)) AS `actUserName`,
              `a`.`actId`                                           AS `actId`,
              `a`.`actName`                                         AS `actName`,
              `a`.`doAction`                                        AS `doAction`,
              (CASE WHEN isnull(`a`.`result`)
                THEN '待办理'
               ELSE `a`.`result` END)                               AS `result`,
              `a`.`remark`                                          AS `remark`,
              `a`.`startDate`                                       AS `startDate`,
              `a`.`endDate`                                         AS `endDate`,
              `a`.`status`                                          AS `status`
            FROM `cscl`.`wf_task` `a`;
