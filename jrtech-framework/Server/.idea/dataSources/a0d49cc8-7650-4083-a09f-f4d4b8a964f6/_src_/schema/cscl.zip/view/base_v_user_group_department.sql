CREATE VIEW base_v_user_group_department AS
  SELECT
    `a`.`id`                   AS `id`,
    `a`.`name`                 AS `name`,
    `a`.`age`                  AS `age`,
    `a`.`birthday`             AS `birthday`,
    `a`.`loginId`              AS `loginId`,
    `a`.`loginPassword`        AS `loginPassword`,
    `a`.`activited`            AS `activited`,
    `a`.`mobile`               AS `mobile`,
    `a`.`email`                AS `email`,
    `a`.`remark`               AS `remark`,
    `a`.`lastLoginTime`        AS `lastLoginTime`,
    `a`.`gmtCreatedBy`         AS `gmtCreatedBy`,
    `a`.`gmtCreatedOn`         AS `gmtCreatedOn`,
    `a`.`gmtUpdatedBy`         AS `gmtUpdatedBy`,
    `a`.`gmtUpdatedOn`         AS `gmtUpdatedOn`,
    `a`.`gmtVersion`           AS `gmtVersion`,
    `a`.`shouldChangePassword` AS `shouldChangePassword`,
    `c`.`roleCategoryId`       AS `roleCategoryId`,
    `c`.`groupId`              AS `groupId`,
    `c`.`groupName`            AS `groupName`,
    `c`.`departmentId`         AS `departmentId`,
    `c`.`departmentName`       AS `departmentName`
  FROM ((`hq`.`base_user` `a`
    JOIN `hq`.`base_user_role` `b` ON ((`a`.`id` = `b`.`userId`))) JOIN `hq`.`base_v_role_group_department` `c`
      ON ((`b`.`roleId` = `c`.`id`)));
