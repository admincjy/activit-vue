CREATE VIEW pl_v_loan_recovery_schedule_aggregation AS
  SELECT
    `a`.`loanDocId`                                                 AS `loanDocId`,
    `a`.`termNO`                                                    AS `termNO`,
    sum(`a`.`planCapitalAmount`)                                    AS `planCapitalAmount`,
    sum(`a`.`planHandlingAmount`)                                   AS `planHandlingAmount`,
    sum(`a`.`planTaxAmount`)                                        AS `planTaxAmount`,
    sum(`a`.`planServiceAmount`)                                    AS `planServiceAmount`,
    sum(`a`.`planMgrAmount`)                                        AS `planMgrAmount`,
    sum(`a`.`planOverdueAmount`)                                    AS `planOverdueAmount`,
    sum(`a`.`planOverdueBreachOfContractAmount`)                    AS `planOverdueBreachOfContractAmount`,
    sum(
        `a`.`planAheadOfTimeRecoveryClearedBreachOfContractAmount`) AS `planAheadOfTimeRecoveryClearedBreachOfContractAmount`,
    sum(`a`.`planOtherAmount`)                                      AS `planOtherAmount`,
    sum(`a`.`planCarGPSMoneyAmount`)                                AS `planCarGPSMoneyAmount`,
    sum(`a`.`planCarDpositMoneyAmount`)                             AS `planCarDpositMoneyAmount`,
    sum(`a`.`planCarStopMoneyAmount`)                               AS `planCarStopMoneyAmount`,
    sum(`a`.`planCarInsuranceMoneyAmount`)                          AS `planCarInsuranceMoneyAmount`,
    max(`a`.`planSettleDate`)                                       AS `planSettleDate`
  FROM `cscl`.`pl_loan_recovery_schedule` `a`
  GROUP BY `a`.`loanDocId`, `a`.`termNO`;
