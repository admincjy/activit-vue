CREATE VIEW pl_v_loan_recovery_schedule_impl AS
  SELECT
    `a`.`loanDocId`                                                                                  AS `loanDocId`,
    `a`.`termNO`                                                                                     AS `termNO`,
    `a`.`planSettleDate`                                                                             AS `planSettleDate`,
    (CASE WHEN isnull(`BASE_GETNEXTNOWKDATE`(`a`.`planSettleDate`))
      THEN `a`.`planSettleDate`
     ELSE `BASE_GETNEXTNOWKDATE`(
         `a`.`planSettleDate`) END)                                                                  AS `planReturnDate`,
    `a`.`planCapitalAmount`                                                                          AS `planCapitalAmount`,
    `a`.`planHandlingAmount`                                                                         AS `planHandlingAmount`,
    `a`.`planTaxAmount`                                                                              AS `planTaxAmount`,
    `a`.`planServiceAmount`                                                                          AS `planServiceAmount`,
    `a`.`planMgrAmount`                                                                              AS `planMgrAmount`,
    `a`.`planOverdueAmount`                                                                          AS `planOverdueAmount`,
    `a`.`planOverdueBreachOfContractAmount`                                                          AS `planOverdueBreachOfContractAmount`,
    `a`.`planAheadOfTimeRecoveryClearedBreachOfContractAmount`                                       AS `planAheadOfTimeRecoveryClearedBreachOfContractAmount`,
    `a`.`planOtherAmount`                                                                            AS `planOtherAmount`,
    `a`.`planCarGPSMoneyAmount`                                                                      AS `planCarGPSMoneyAmount`,
    `a`.`planCarDpositMoneyAmount`                                                                   AS `planCarDpositMoneyAmount`,
    `a`.`planCarStopMoneyAmount`                                                                     AS `planCarStopMoneyAmount`,
    `a`.`planCarInsuranceMoneyAmount`                                                                AS `planCarInsuranceMoneyAmount`,
    ifnull(`b`.`returnCapitalAmount`,
           0)                                                                                        AS `returnCapitalAmount`,
    ifnull(`b`.`returnHandlingAmount`,
           0)                                                                                        AS `returnHandlingAmount`,
    ifnull(`b`.`returnTaxAmount`,
           0)                                                                                        AS `returnTaxAmount`,
    ifnull(`b`.`returnServiceAmount`,
           0)                                                                                        AS `returnServiceAmount`,
    ifnull(`b`.`returnMgrAmount`,
           0)                                                                                        AS `returnMgrAmount`,
    ifnull(`b`.`returnOverdueAmount`,
           0)                                                                                        AS `returnOverdueAmount`,
    ifnull(`b`.`returnOverdueBreachOfContractAmount`,
           0)                                                                                        AS `returnOverdueBreachOfContractAmount`,
    ifnull(`b`.`returnAheadOfTimeRecoveryClearedBreachOfContractAmount`,
           0)                                                                                        AS `returnAheadOfTimeRecoveryClearedBreachOfContractAmount`,
    ifnull(`b`.`returnOtherAmount`,
           0)                                                                                        AS `returnOtherAmount`,
    ifnull(`b`.`returnCarGPSMoneyAmount`,
           0)                                                                                        AS `returnCarGPSMoneyAmount`,
    ifnull(`b`.`returnCarDpositMoneyAmount`,
           0)                                                                                        AS `returnCarDpositMoneyAmount`,
    ifnull(`b`.`returnCarStopMoneyAmount`,
           0)                                                                                        AS `returnCarStopMoneyAmount`,
    ifnull(`b`.`returnCarInsuranceMoneyAmount`,
           0)                                                                                        AS `returnCarInsuranceMoneyAmount`,
    (`a`.`planCapitalAmount` - ifnull(`b`.`returnCapitalAmount`,
                                      0))                                                            AS `remainCapitalAmount`,
    (`a`.`planHandlingAmount` - ifnull(`b`.`returnHandlingAmount`,
                                       0))                                                           AS `remainHandlingAmount`,
    (`a`.`planTaxAmount` - ifnull(`b`.`returnTaxAmount`,
                                  0))                                                                AS `remainTaxAmount`,
    (`a`.`planServiceAmount` - ifnull(`b`.`returnServiceAmount`,
                                      0))                                                            AS `remainServiceAmount`,
    (`a`.`planMgrAmount` - ifnull(`b`.`returnMgrAmount`,
                                  0))                                                                AS `remainMgrAmount`,
    (`a`.`planOverdueAmount` - ifnull(`b`.`returnOverdueAmount`,
                                      0))                                                            AS `remainOverdueAmount`,
    (`a`.`planOverdueBreachOfContractAmount` - ifnull(`b`.`returnOverdueBreachOfContractAmount`,
                                                      0))                                            AS `remainOverdueBreachOfContractAmount`,
    (`a`.`planAheadOfTimeRecoveryClearedBreachOfContractAmount` -
     ifnull(`b`.`returnAheadOfTimeRecoveryClearedBreachOfContractAmount`,
            0))                                                                                      AS `remainAheadOfTimeRecoveryClearedBreachOfContractAmount`,
    (`a`.`planOtherAmount` - ifnull(`b`.`returnOtherAmount`,
                                    0))                                                              AS `remainOtherAmount`,
    (`a`.`planCarGPSMoneyAmount` - ifnull(`b`.`returnCarGPSMoneyAmount`,
                                          0))                                                        AS `remainCarGPSMoneyAmount`,
    (`a`.`planCarDpositMoneyAmount` - ifnull(`b`.`returnCarDpositMoneyAmount`,
                                             0))                                                     AS `remainCarDpositMoneyAmount`,
    (`a`.`planCarStopMoneyAmount` - ifnull(`b`.`returnCarStopMoneyAmount`,
                                           0))                                                       AS `remainCarStopMoneyAmount`,
    (`a`.`planCarInsuranceMoneyAmount` - ifnull(`b`.`returnCarInsuranceMoneyAmount`,
                                                0))                                                  AS `remainCarInsuranceMoneyAmount`,
    (CASE WHEN ((`a`.`planCapitalAmount` = ifnull(`b`.`returnCapitalAmount`, 0)) AND
                (`a`.`planServiceAmount` = ifnull(`b`.`returnServiceAmount`, 0)) AND
                (`a`.`planTaxAmount` = ifnull(`b`.`returnTaxAmount`, 0)))
      THEN '结清'
     WHEN ((isnull(`b`.`returnCapitalAmount`) OR (`b`.`returnCapitalAmount` = 0)) AND
           (isnull(`b`.`returnServiceAmount`) OR (`b`.`returnServiceAmount` = 0)) AND
           (isnull(`b`.`returnTaxAmount`) OR (`b`.`returnTaxAmount` = 0)))
       THEN '未还'
     ELSE '部分结清' END)                                                                                AS `returnStatus`,
    `b`.`lastReturnDate`                                                                             AS `lastReturnDate`
  FROM (`cscl`.`pl_v_loan_recovery_schedule_aggregation` `a` LEFT JOIN
    `cscl`.`pl_v_loan_recovery_schedule_detail_aggregation` `b`
      ON (((`a`.`loanDocId` = `b`.`loanDocId`) AND (`a`.`termNO` = `b`.`termNO`))));
