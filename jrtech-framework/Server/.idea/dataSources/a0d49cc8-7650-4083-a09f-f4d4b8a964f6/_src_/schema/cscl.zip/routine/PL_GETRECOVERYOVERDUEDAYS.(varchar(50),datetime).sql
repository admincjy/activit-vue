CREATE FUNCTION PL_GETRECOVERYOVERDUEDAYS(p_loanDocId VARCHAR(50), p_planreturnDate DATETIME)
  RETURNS INT
  BEGIN  

    DECLARE p_nextplanreturnDate datetime;

	 DECLARE p_lastScheduleTermNo int;

	 DECLARE p_startOverdureDay datetime;

	 DECLARE p_lastPlanSettleDate datetime;

	 DECLARE p_lastPlanReturnDate datetime; 

	 DECLARE p_lastReturnDate datetime;

	  

	 set p_nextplanreturnDate = DATE(DATE_ADD(p_planreturnDate,INTERVAL 1 DAY));

	  
	 select termNO,planSettleDate,base_getNextNoWkDate(planSettleDate) p_lastPlanReturnDate,DATE(lastReturnDate) into p_lastScheduleTermNo, p_lastPlanSettleDate,p_lastPlanReturnDate,p_lastReturnDate
	 from
	 (
		 select  a.termNO,a.planSettleDate,b.lastReturnDate,a.sumPlanCapitalAmount,a.sumPlanServiceAmount,a.sumPlanTaxAmount,IFNULL(b.sumReturnCapitalAmount,0) sumReturnCapitalAmount,IFNULL(b.sumReturnServiceAmount,0) sumReturnServiceAmount,IFNULL(b.sumReturnTaxAmount,0)  sumReturnTaxAmount from
		 (
			select termNO,min(planSettleDate) planSettleDate,sum(planCapitalAmount) sumPlanCapitalAmount,sum(planServiceAmount) sumPlanServiceAmount,sum(planTaxAmount) sumPlanTaxAmount from pl_loan_recovery_schedule where loanDocId = p_loanDocId and loanSourceDate< p_nextplanreturnDate  and base_getNextNoWkDate(planSettleDate) < p_nextplanreturnDate group by termNO
		 )  a
		 left join
		 (
			select termNO,max(returnDate) lastReturnDate,sum(returnCapitalAmount) sumReturnCapitalAmount,sum(returnServiceAmount) sumReturnServiceAmount,sum(returnTaxAmount) sumReturnTaxAmount  from pl_loan_recovery_schedule_detail a where loanDocId = p_loanDocId  and returnDate<p_nextplanreturnDate group by termNo
		 )  b
		 on a.termNO = b.termNO 
	) aa 
	where sumPlanCapitalAmount<>sumReturnCapitalAmount or sumPlanTaxAmount<>sumReturnTaxAmount or sumPlanServiceAmount<> sumReturnServiceAmount
	order by termNO asc limit 0,1;

	 

    set p_startOverdureDay = p_lastPlanSettleDate;


	RETURN  datediff(DATE(p_planreturnDate),p_startOverdureDay);  

END;
