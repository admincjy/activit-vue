CREATE FUNCTION PL_GETDEBTCOLLECTIONBEOFSTAGETYPE(p_loanDocId VARCHAR(50), p_returnDate DATETIME, p_loanTermNO INT)
  RETURNS VARCHAR(20)
  BEGIN  

	DECLARE p_overdueDays int;

	declare p_transferStage varchar(20);

	DECLARE p_manualTransferStage varchar(20); 



	set p_overdueDays = pl_getRecoveryOverdueDays(p_loanDocId,p_returnDate);

	select  manualTransferStage into p_manualTransferStage from pl_loan_debt_collection_manual_transfer_doc  where loanDocId=p_loanDocId and loanRecoveryTermNO=p_loanTermNO order by gmtCreatedOn desc limit 0,1; 



	if p_overdueDays>=-3 and p_overdueDays<=1 then 

		set p_transferStage= 'a_0'; 

	end if;

	if p_overdueDays>=2 and p_overdueDays<=6 then 

		set p_transferStage= 'b_0'; 

	end if;

	if p_overdueDays>=7  then 

		set p_transferStage= 'c_0'; 

	end if;



   

	if p_manualTransferStage is not null and p_manualTransferStage>p_transferStage then 

		set p_transferStage = p_manualTransferStage;

	end if;



	RETURN  p_transferStage;  

END;
