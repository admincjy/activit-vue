CREATE PROCEDURE base_getSequenceNumber(IN p_CODE VARCHAR(50), IN p_COUNT INT)
  BEGIN

	DECLARE v_NewValue VARCHAR(20);

	DECLARE v_CurrentDate VARCHAR(8);

	DECLARE v_Prefix VARCHAR(10);

	DECLARE v_DateType VARCHAR(8);

	DECLARE v_Infix VARCHAR(5);

	DECLARE v_Suffix VARCHAR(5);

	DECLARE v_MaxIndex INT;

	DECLARE v_IndexLength TINYINT;

	DECLARE v_MaxDate VARCHAR(8);

	

	IF p_COUNT IS NULL THEN

	   SET p_COUNT = 1;

	END IF;

 

	SET SQL_SAFE_UPDATES=0;

	START TRANSACTION;

		

		SELECT  Prefix,Infix,Suffix,DateType,MaxDate, MaxIndex, IndexLength FROM base_sequence_number  WHERE CODE=p_CODE 

		INTO v_Prefix,v_Infix,v_Suffix,v_DateType,v_MaxDate,v_MaxIndex,v_IndexLength FOR UPDATE;

		

		

		SET v_CurrentDate= DATE_FORMAT(NOW(), '%Y%m%d');

		

		IF(v_CurrentDate = v_MaxDate) THEN	

			SET v_MaxIndex = v_MaxIndex + p_COUNT;

		ELSE

			SET v_MaxIndex = p_COUNT; 

		

		END IF;

		

		

		IF(v_MaxIndex >= POWER(10, v_IndexLength))  THEN

			SET v_IndexLength = v_IndexLength + 1; 

		END IF;

	

			

		UPDATE base_sequence_number SET MaxDate = v_CurrentDate, MaxIndex=v_MaxIndex, IndexLength=v_IndexLength WHERE CODE=p_CODE;

		

		

		SELECT  CONCAT(v_Prefix ,v_CurrentDate , v_Infix , LPAD(v_MaxIndex,v_IndexLength,'0') ,v_Suffix),v_IndexLength,LENGTH(v_Suffix)

	

	COMMIT;

	

	SET SQL_SAFE_UPDATES=1;

	

    END;
