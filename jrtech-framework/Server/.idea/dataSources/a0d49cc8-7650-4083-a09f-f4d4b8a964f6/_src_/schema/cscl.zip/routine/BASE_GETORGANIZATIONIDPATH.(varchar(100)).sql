CREATE FUNCTION BASE_GETORGANIZATIONIDPATH(p_orgId VARCHAR(100))
  RETURNS VARCHAR(2000)
  BEGIN

	DECLARE v_path VARCHAR(2000);

	DECLARE v_thisId VARCHAR(100);

	DECLARE v_parentId VARCHAR(100); 

	SELECT Id,parentId,id FROM Base_Organization WHERE Id = p_orgId INTO v_thisId ,v_parentId,v_path;

	

 SET v_path = CONCAT('/',v_path);

	WHILE v_parentId IS NOT NULL && EXISTS(SELECT 1 FROM Base_Organization WHERE Id = v_parentId) DO

		SELECT Id,parentId FROM Base_Organization WHERE Id = v_parentId  INTO v_thisId ,v_parentId;

		SET v_path = CONCAT(v_path , '/' , v_thisId);

	END WHILE;

	

    SET v_path = CONCAT(v_path,'/');

    

    RETURN v_path;

	 

    

END;
