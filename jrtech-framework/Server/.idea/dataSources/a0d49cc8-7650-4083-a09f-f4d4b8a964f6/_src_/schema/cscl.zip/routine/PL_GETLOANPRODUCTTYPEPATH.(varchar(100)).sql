CREATE FUNCTION PL_GETLOANPRODUCTTYPEPATH(p_loanProductSubTypeId VARCHAR(100))
  RETURNS VARCHAR(2000)
  BEGIN

	DECLARE v_path VARCHAR(2000);

	DECLARE v_loanProductTypeId VARCHAR(100);

	DECLARE v_loanProductTypeName VARCHAR(100);

    SELECT LoanProductTypeId,NAME FROM pl_loan_product_sub_type WHERE Id = p_loanProductSubTypeId INTO v_loanProductTypeId ,v_path;

	SELECT NAME FROM pl_loan_product_type WHERE Id = v_loanProductTypeId INTO v_loanProductTypeName;

	SET v_path = CONCAT(v_loanProductTypeName , '->' , v_path);

 

    RETURN v_path;

	 

    

END;
