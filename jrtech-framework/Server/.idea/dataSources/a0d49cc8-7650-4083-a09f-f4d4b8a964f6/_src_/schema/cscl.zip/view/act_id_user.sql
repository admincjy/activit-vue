CREATE VIEW act_id_user AS
  (SELECT
     `au`.`loginId` AS `ID_`,
     0              AS `REV_`,
     `au`.`name`    AS `FIRST_`,
     ''             AS `LAST_`,
     `au`.`email`   AS `EMAIL_`,
     ''             AS `PWD_`,
     ''             AS `PICTURE_ID_`
   FROM `cscl`.`base_user` `au`);
