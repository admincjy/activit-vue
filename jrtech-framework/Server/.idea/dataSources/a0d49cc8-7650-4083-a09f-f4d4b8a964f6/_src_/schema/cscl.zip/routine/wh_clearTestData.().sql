CREATE PROCEDURE wh_clearTestData()
  BEGIN

SET foreign_key_checks = 0; 



 

TRUNCATE `base_log`;

TRUNCATE `base_notification`;

TRUNCATE `base_schedule_job_log`;

TRUNCATE `base_attachment`;



TRUNCATE `pl_loan_doc`;

TRUNCATE `pl_loan_enter_gxd`;

TRUNCATE `pl_loan_recovery_doc`;

TRUNCATE `pl_loan_recovery_schedule`;

TRUNCATE `pl_loan_recovery_schedule_detail`;



TRUNCATE `wf_processinst`;

TRUNCATE `wf_task`;



TRUNCATE  `qrtz_triggers`;



 

TRUNCATE act_hi_actinst;

TRUNCATE act_hi_attachment ;

TRUNCATE act_hi_comment    ;

TRUNCATE act_hi_detail      ;

TRUNCATE act_hi_identitylink ;

TRUNCATE act_hi_identitylink ;

TRUNCATE act_hi_procinst   ;

TRUNCATE act_hi_taskinst ;

TRUNCATE act_hi_varinst  ;

TRUNCATE act_ru_event_subscr;

TRUNCATE act_ru_identitylink ;

TRUNCATE act_ru_identitylink;

TRUNCATE act_ru_task   ;

TRUNCATE act_ru_variable   ;

TRUNCATE act_ru_execution   ;





SET foreign_key_checks = 1; 

END;
