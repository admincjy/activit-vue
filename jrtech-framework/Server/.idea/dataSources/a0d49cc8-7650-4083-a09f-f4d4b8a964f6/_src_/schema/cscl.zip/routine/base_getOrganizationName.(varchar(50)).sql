CREATE FUNCTION base_getOrganizationName(aid VARCHAR(50))
  RETURNS VARCHAR(100)
  BEGIN

RETURN (SELECT NAME FROM base_organization WHERE id=aid LIMIT 1);

END;
