CREATE VIEW base_v_group_department AS
  SELECT
    `aa`.`id`                                                     AS `id`,
    `aa`.`parentId`                                               AS `parentId`,
    `aa`.`name`                                                   AS `name`,
    `aa`.`remark`                                                 AS `remark`,
    `aa`.`address`                                                AS `address`,
    `aa`.`postNO`                                                 AS `postNO`,
    `aa`.`type`                                                   AS `type`,
    `aa`.`organizationCategoryId`                                 AS `organizationCategoryId`,
    `aa`.`gmtCreatedBy`                                           AS `gmtCreatedBy`,
    `aa`.`gmtCreatedOn`                                           AS `gmtCreatedOn`,
    `aa`.`gmtUpdatedBy`                                           AS `gmtUpdatedBy`,
    `aa`.`gmtUpdatedOn`                                           AS `gmtUpdatedOn`,
    `aa`.`gmtVersion`                                             AS `gmtVersion`,
    `aa`.`departmentId`                                           AS `departmentId`,
    (SELECT `hq`.`base_organization`.`name`
     FROM `hq`.`base_organization`
     WHERE (`hq`.`base_organization`.`id` = `aa`.`departmentId`)) AS `departmentName`
  FROM (SELECT
          `a`.`id`                                       AS `id`,
          `a`.`parentId`                                 AS `parentId`,
          `a`.`name`                                     AS `name`,
          `a`.`remark`                                   AS `remark`,
          `a`.`address`                                  AS `address`,
          `a`.`postNO`                                   AS `postNO`,
          `a`.`type`                                     AS `type`,
          `a`.`organizationCategoryId`                   AS `organizationCategoryId`,
          `a`.`gmtCreatedBy`                             AS `gmtCreatedBy`,
          `a`.`gmtCreatedOn`                             AS `gmtCreatedOn`,
          `a`.`gmtUpdatedBy`                             AS `gmtUpdatedBy`,
          `a`.`gmtUpdatedOn`                             AS `gmtUpdatedOn`,
          `a`.`gmtVersion`                               AS `gmtVersion`,
          `base_getOrganizationOfDepartmentId`(`a`.`id`) AS `departmentId`
        FROM `hq`.`base_organization` `a`) `aa`;
