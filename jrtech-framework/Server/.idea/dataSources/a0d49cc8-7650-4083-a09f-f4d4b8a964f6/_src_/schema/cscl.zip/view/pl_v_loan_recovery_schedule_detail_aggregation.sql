CREATE VIEW pl_v_loan_recovery_schedule_detail_aggregation AS
  SELECT
    `a`.`loanDocId`                                                   AS `loanDocId`,
    `a`.`termNO`                                                      AS `termNO`,
    sum(`a`.`returnCapitalAmount`)                                    AS `returnCapitalAmount`,
    sum(`a`.`returnHandlingAmount`)                                   AS `returnHandlingAmount`,
    sum(`a`.`returnTaxAmount`)                                        AS `returnTaxAmount`,
    sum(`a`.`returnServiceAmount`)                                    AS `returnServiceAmount`,
    sum(`a`.`returnMgrAmount`)                                        AS `returnMgrAmount`,
    sum(`a`.`returnOverdueAmount`)                                    AS `returnOverdueAmount`,
    sum(`a`.`returnOverdueBreachOfContractAmount`)                    AS `returnOverdueBreachOfContractAmount`,
    sum(
        `a`.`returnAheadOfTimeRecoveryClearedBreachOfContractAmount`) AS `returnAheadOfTimeRecoveryClearedBreachOfContractAmount`,
    sum(`a`.`returnOtherAmount`)                                      AS `returnOtherAmount`,
    sum(`a`.`returnCarGPSMoneyAmount`)                                AS `returnCarGPSMoneyAmount`,
    sum(`a`.`returnCarDpositMoneyAmount`)                             AS `returnCarDpositMoneyAmount`,
    sum(`a`.`returnCarStopMoneyAmount`)                               AS `returnCarStopMoneyAmount`,
    sum(`a`.`returnCarInsuranceMoneyAmount`)                          AS `returnCarInsuranceMoneyAmount`,
    max(`a`.`returnDate`)                                             AS `lastReturnDate`
  FROM `cscl`.`pl_loan_recovery_schedule_detail` `a`
  GROUP BY `a`.`loanDocId`, `a`.`termNO`;
