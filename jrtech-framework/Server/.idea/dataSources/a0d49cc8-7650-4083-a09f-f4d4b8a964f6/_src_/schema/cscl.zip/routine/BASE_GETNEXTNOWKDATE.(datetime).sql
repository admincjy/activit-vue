CREATE FUNCTION BASE_GETNEXTNOWKDATE(p_currDate DATETIME)
  RETURNS DATETIME
  BEGIN

declare p_nextDate datetime;

select cdate into p_nextDate from base_holiday_set where  wk = 0 and cdate>=p_currDate order by cdate asc limit 0,1;

return p_nextDate;

END;
