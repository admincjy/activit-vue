CREATE VIEW wf_v_todotask AS
  SELECT
    `a`.`ID_`           AS `TASK_ID`,
    `a`.`PROC_INST_ID_` AS `PROC_INST_ID`,
    `a`.`TASK_DEF_KEY_` AS `ACT_ID`,
    `a`.`NAME_`         AS `ACT_NAME`,
    `a`.`ASSIGNEE_`     AS `ASSIGNEE`,
    `a`.`DELEGATION_`   AS `DELEGATION_ID`,
    `a`.`DESCRIPTION_`  AS `DESCRIPTION`,
    `a`.`CREATE_TIME_`  AS `CREATE_TIME`,
    `a`.`DUE_DATE_`     AS `DUE_DATE`,
    `i`.`USER_ID`       AS `CANDIDATE`,
    `a`.`FORM_KEY_`     AS `FORM_KEY`
  FROM (`hq`.`act_ru_task` `a` LEFT JOIN (SELECT DISTINCT
                                            `u`.`TASK_ID_` AS `TASK_ID_`,
                                            `u`.`USER_ID`  AS `USER_ID`
                                          FROM (SELECT
                                                  `i`.`TASK_ID_` AS `TASK_ID_`,
                                                  `i`.`USER_ID_` AS `USER_ID`
                                                FROM (`hq`.`act_ru_identitylink` `i`
                                                  JOIN `hq`.`act_ru_task` `t`)
                                                WHERE ((`i`.`TASK_ID_` IS NOT NULL) AND (`i`.`USER_ID_` IS NOT NULL) AND
                                                       (`i`.`TASK_ID_` = `t`.`ID_`) AND isnull(`t`.`ASSIGNEE_`) AND
                                                       (`i`.`TYPE_` = 'candidate'))
                                                UNION SELECT
                                                        `i`.`TASK_ID_` AS `TASK_ID_`,
                                                        `r`.`USER_ID_` AS `USER_ID`
                                                      FROM ((`hq`.`act_ru_identitylink` `i`
                                                        JOIN `hq`.`act_id_membership` `r`) JOIN `hq`.`act_ru_task` `t`)
                                                      WHERE (
                                                        (`i`.`TASK_ID_` IS NOT NULL) AND (`i`.`GROUP_ID_` IS NOT NULL)
                                                        AND (`i`.`TASK_ID_` = `t`.`ID_`) AND isnull(`t`.`ASSIGNEE_`) AND
                                                        (`i`.`TYPE_` = 'candidate') AND
                                                        (`i`.`GROUP_ID_` = `r`.`GROUP_ID_`))) `u`) `i`
      ON ((`a`.`ID_` = `i`.`TASK_ID_`)));
