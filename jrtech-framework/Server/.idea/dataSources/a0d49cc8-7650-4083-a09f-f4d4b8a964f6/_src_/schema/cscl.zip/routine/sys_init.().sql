CREATE PROCEDURE sys_init()
  BEGIN





 

  SET SQL_SAFE_UPDATES=0;



 delete from base_permission where id <>'common';

 

 insert into base_permission

 select CONCAT('menu_', id),( case when length(parentId) = 0 or parentId is null then '' else CONCAT('menu_', parentId) end) parentId,name,'' remark,sortindex from base_navigation

 where (requiredPermissionId<> 'common') and `show` = 1 ;

 

 update   base_permission a

 inner join base_navigation b

 on b.requiredPermissionId = a.id

 set a.sortIndex = b.sortIndex,

a.name = b.title;





 

delete from base_role_permission where roleId='system_admin';

insert into base_role_permission select CONCAT('sa_', id), id,'system_admin' from base_permission;



 SET SQL_SAFE_UPDATES=1;

END;
