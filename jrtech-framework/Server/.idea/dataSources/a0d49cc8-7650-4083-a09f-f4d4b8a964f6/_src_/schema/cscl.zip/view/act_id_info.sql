CREATE VIEW act_id_info AS
  (SELECT
     `u`.`id`            AS `ID_`,
     0                   AS `REV_`,
     NULL                AS `USER_ID_`,
     NULL                AS `TYPE_`,
     NULL                AS `KEY_`,
     NULL                AS `VALUE_`,
     `u`.`loginPassword` AS `PASSWORD_`,
     NULL                AS `PARENT_ID_`
   FROM `cscl`.`base_user` `u`);
