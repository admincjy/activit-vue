CREATE FUNCTION pl_getLoanDocRemainCapitalAmount(loanDocId VARCHAR(50))
  RETURNS DECIMAL(18, 2)
  BEGIN



declare p_remainCapitalAmount decimal(18,2);



select sum(remainCapitalAmount) into p_remainCapitalAmount from pl_v_loan_recovery_schedule_impl where loanDocId = p_loanDocId;



return p_remainCapitalAmount;

END;
