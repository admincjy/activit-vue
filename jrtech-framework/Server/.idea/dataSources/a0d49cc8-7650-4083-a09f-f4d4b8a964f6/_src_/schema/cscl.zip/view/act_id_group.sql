CREATE VIEW act_id_group AS
  (SELECT
     `r`.`id`   AS `ID_`,
     NULL       AS `REV_`,
     `r`.`name` AS `NAME_`,
     `r`.`type` AS `TYPE_`
   FROM `cscl`.`base_role` `r`);
